"""
P.O.P.S. ORB — Legal Semantic Knowledge Graph (SKG)
Bounded to custody/parenting domain only.
Seedable. Grows from verified user case data over time.
"""

import json
import hashlib
from dataclasses import dataclass, field, asdict
from typing import Optional
from pathlib import Path
from datetime import datetime


@dataclass
class SKGNode:
    """A concept node in the legal knowledge graph."""
    node_id: str
    label: str
    category: str
    definition: str
    court_language: str
    related_ids: list[str] = field(default_factory=list)
    evidence_types: list[str] = field(default_factory=list)
    risk_flags: list[str] = field(default_factory=list)
    jurisdiction_notes: str = ""
    seeded: bool = True


@dataclass
class SKGEdge:
    """A relationship between two nodes."""
    from_id: str
    to_id: str
    relationship: str
    weight: float = 1.0


class LegalSKG:
    """
    Semantic Knowledge Graph for the P.O.P.S. ORB.

    This is the learning layer. It starts seeded with core custody/parenting
    concepts and grows as verified case data is added. It does NOT learn from
    LLM outputs — only from user-confirmed case facts and approved sources.
    """

    CATEGORIES = [
        "court_concept", "evidence_type", "procedure",
        "risk", "document", "person_role", "relief_type"
    ]

    def __init__(self, storage_path: str = "pops_skg.json"):
        self.storage_path = Path(storage_path)
        self.nodes: dict[str, SKGNode] = {}
        self.edges: list[SKGEdge] = []
        self._load_or_seed()

    def _load_or_seed(self):
        if self.storage_path.exists():
            self._load()
        else:
            self._seed()
            self._save()

    def _seed(self):
        """Seed the SKG with core custody/parenting domain knowledge."""

        seed_nodes = [
            SKGNode("parenting_time", "Parenting Time", "court_concept",
                    "The scheduled periods when a parent has physical custody of the child.",
                    "parenting time as ordered",
                    related_ids=["custody_order", "denied_visit", "parenting_plan"],
                    evidence_types=["calendar records", "text messages", "witness statements"],
                    risk_flags=["denial of parenting time may constitute contempt"]),

            SKGNode("custody_order", "Custody Order", "document",
                    "A court-issued document specifying legal and physical custody arrangements.",
                    "pursuant to the existing order of this court",
                    related_ids=["parenting_time", "contempt", "modification"],
                    evidence_types=["certified copy of order"],
                    risk_flags=["violations trigger contempt exposure"]),

            SKGNode("denied_visit", "Denied Parenting Time", "court_concept",
                    "An incident where one parent prevents the other from exercising court-ordered parenting time.",
                    "interference with court-ordered parenting time",
                    related_ids=["parenting_time", "contempt", "communication_record"],
                    evidence_types=["text messages", "call logs", "witness", "police report"],
                    risk_flags=["document each incident separately", "police report recommended"]),

            SKGNode("contempt", "Contempt of Court", "court_concept",
                    "Willful disobedience of a court order. May result in fines, make-up time, or incarceration.",
                    "in willful violation of the order of this court",
                    related_ids=["custody_order", "denied_visit", "motion_to_enforce"],
                    evidence_types=["certified order copy", "documented violations", "communication logs"],
                    risk_flags=["must show willfulness", "pattern strengthens case"]),

            SKGNode("communication_record", "Communication Record", "evidence_type",
                    "Documented communication between parties, including texts, emails, voicemails.",
                    "as evidenced by the attached communication records",
                    related_ids=["denied_visit", "exhibit"],
                    evidence_types=["screenshots with metadata", "email printouts", "voicemail transcripts"]),

            SKGNode("child_support", "Child Support", "court_concept",
                    "Court-ordered financial obligation from one parent to another for child expenses.",
                    "child support as ordered by this court",
                    related_ids=["license_suspension", "contempt", "income_withholding"],
                    risk_flags=["non-payment triggers license risk", "arrears accrue automatically"]),

            SKGNode("license_suspension", "License Suspension", "risk",
                    "Driver or professional license suspension for non-payment of child support.",
                    "potential license suspension pursuant to support enforcement",
                    related_ids=["child_support"],
                    risk_flags=["can occur administratively without court hearing"]),

            SKGNode("exhibit", "Exhibit", "document",
                    "A labeled piece of evidence formally introduced in court proceedings.",
                    "Petitioner's Exhibit [letter], admitted into evidence",
                    related_ids=["evidence_vault", "chain_of_custody"],
                    evidence_types=["labeled physical documents", "authenticated digital records"]),

            SKGNode("chain_of_custody", "Chain of Custody", "procedure",
                    "The documented sequence of possession and control of evidence.",
                    "chain of custody maintained from collection to submission",
                    related_ids=["exhibit", "evidence_vault"],
                    risk_flags=["gaps in chain weaken admissibility"]),

            SKGNode("motion_to_enforce", "Motion to Enforce", "document",
                    "A formal court filing requesting the court compel compliance with an existing order.",
                    "Petitioner's Motion to Enforce Order of [date]",
                    related_ids=["contempt", "custody_order", "denied_visit"]),

            SKGNode("parenting_plan", "Parenting Plan", "document",
                    "A detailed agreement or order specifying the schedule, decision-making, and rules for co-parenting.",
                    "pursuant to the parenting plan incorporated in the order of this court",
                    related_ids=["parenting_time", "custody_order", "modification"]),

            SKGNode("modification", "Modification of Order", "procedure",
                    "A court process to change an existing custody or support order based on changed circumstances.",
                    "motion to modify the existing order of this court",
                    related_ids=["custody_order", "parenting_plan"],
                    risk_flags=["requires showing of material change in circumstances"]),

            SKGNode("guardian_ad_litem", "Guardian ad Litem", "person_role",
                    "A court-appointed representative who advocates for the best interests of the child.",
                    "guardian ad litem appointed by this court",
                    related_ids=["best_interest", "custody_order"]),

            SKGNode("best_interest", "Best Interest of the Child", "court_concept",
                    "The legal standard courts use when making custody and parenting decisions.",
                    "in the best interest of the minor child",
                    related_ids=["custody_order", "guardian_ad_litem", "modification"]),

            SKGNode("medical_access", "Medical Access", "court_concept",
                    "A parent's right to access the child's medical records and participate in medical decisions.",
                    "legal right to access medical records and participate in medical decisions",
                    related_ids=["custody_order", "best_interest"]),

            SKGNode("school_access", "School Access", "court_concept",
                    "A parent's right to access the child's school records and communicate with school staff.",
                    "right to access educational records and communicate with school personnel",
                    related_ids=["custody_order", "best_interest"]),

            SKGNode("affidavit", "Affidavit", "document",
                    "A sworn written statement of facts, signed under penalty of perjury.",
                    "affiant states under oath and penalty of perjury",
                    related_ids=["motion_to_enforce", "exhibit"]),

            SKGNode("pro_se", "Pro Se / Self-Represented", "procedure",
                    "Representing oneself in court without an attorney.",
                    "appearing pro se",
                    related_ids=["motion_to_enforce", "attorney_packet"]),

            SKGNode("attorney_packet", "Attorney Packet", "document",
                    "An organized collection of case facts, evidence, and documents prepared for attorney review.",
                    "prepared for attorney review",
                    related_ids=["exhibit", "communication_record", "affidavit"]),

            SKGNode("evidence_vault", "Evidence Vault", "procedure",
                    "Secure, timestamped storage of case evidence with SHA-256 hash verification.",
                    "evidence preserved and authenticated",
                    related_ids=["exhibit", "chain_of_custody"]),
        ]

        seed_edges = [
            SKGEdge("denied_visit", "contempt", "may_constitute"),
            SKGEdge("denied_visit", "communication_record", "requires_evidence"),
            SKGEdge("denied_visit", "parenting_time", "violates"),
            SKGEdge("contempt", "motion_to_enforce", "resolved_by"),
            SKGEdge("custody_order", "parenting_time", "governs"),
            SKGEdge("custody_order", "modification", "subject_to"),
            SKGEdge("communication_record", "exhibit", "becomes"),
            SKGEdge("exhibit", "chain_of_custody", "requires"),
            SKGEdge("child_support", "license_suspension", "non_payment_triggers"),
            SKGEdge("attorney_packet", "exhibit", "contains"),
            SKGEdge("attorney_packet", "affidavit", "contains"),
            SKGEdge("attorney_packet", "communication_record", "contains"),
            SKGEdge("best_interest", "custody_order", "governs"),
            SKGEdge("evidence_vault", "exhibit", "source_of"),
        ]

        for node in seed_nodes:
            self.nodes[node.node_id] = node
        self.edges = seed_edges

    def get_node(self, node_id: str) -> Optional[SKGNode]:
        return self.nodes.get(node_id)

    def find_related(self, node_id: str) -> list[SKGNode]:
        """Return all nodes directly related to this node."""
        related = []
        node = self.get_node(node_id)
        if not node:
            return []
        for related_id in node.related_ids:
            n = self.get_node(related_id)
            if n:
                related.append(n)
        return related

    def search(self, query: str) -> list[SKGNode]:
        """Search nodes by label, definition, or court language."""
        query_lower = query.lower()
        results = []
        for node in self.nodes.values():
            score = 0
            if query_lower in node.label.lower():
                score += 3
            if query_lower in node.definition.lower():
                score += 2
            if query_lower in node.court_language.lower():
                score += 2
            if any(query_lower in rt.lower() for rt in node.risk_flags):
                score += 1
            if score > 0:
                results.append((score, node))
        results.sort(key=lambda x: x[0], reverse=True)
        return [n for _, n in results]

    def link_case_entry(self, entry_type: str, entry_data: dict) -> list[str]:
        """
        Given a case entry (violation, evidence item, event), return a list
        of SKG nodes that should be linked, and flag any missing connections.
        """
        suggestions = []
        gaps = []

        if entry_type == "violation":
            suggestions.append("denied_visit")
            suggestions.append("communication_record")
            suggestions.append("contempt")
            if not entry_data.get("order_id"):
                gaps.append("No court order linked to this violation. Link the relevant order section.")
            if not entry_data.get("evidence_ids"):
                gaps.append("No evidence linked to this violation. Add communication records or witness info.")

        elif entry_type == "evidence":
            suggestions.append("exhibit")
            suggestions.append("chain_of_custody")
            if not entry_data.get("hash"):
                gaps.append("Evidence item has no hash. Verify it was processed through the Evidence Vault.")

        elif entry_type == "event":
            event_type = entry_data.get("type", "").lower()
            if "medical" in event_type:
                suggestions.append("medical_access")
            if "school" in event_type:
                suggestions.append("school_access")
            if "support" in event_type:
                suggestions.append("child_support")
                suggestions.append("license_suspension")

        return suggestions, gaps

    def add_verified_node(self, node: SKGNode):
        """Add a new node from a verified source. Not from LLM output."""
        self.nodes[node.node_id] = node
        self._save()

    def _save(self):
        data = {
            "nodes": {k: asdict(v) for k, v in self.nodes.items()},
            "edges": [asdict(e) for e in self.edges],
            "updated": datetime.now().isoformat(),
        }
        self.storage_path.write_text(json.dumps(data, indent=2))

    def _load(self):
        data = json.loads(self.storage_path.read_text())
        self.nodes = {k: SKGNode(**v) for k, v in data["nodes"].items()}
        self.edges = [SKGEdge(**e) for e in data["edges"]]

    def export_for_prompt(self, relevant_ids: list[str]) -> str:
        """Export relevant SKG nodes as a compact prompt context block."""
        lines = ["LEGAL KNOWLEDGE CONTEXT (approved substrate only):"]
        for node_id in relevant_ids:
            node = self.get_node(node_id)
            if node:
                lines.append(f"\n[{node.label}]")
                lines.append(f"  Definition: {node.definition}")
                lines.append(f"  Court language: {node.court_language}")
                if node.risk_flags:
                    lines.append(f"  Risk flags: {'; '.join(node.risk_flags)}")
        return "\n".join(lines)
