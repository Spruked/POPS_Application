# P.O.P.S. ORB — Integration Guide
# What to add. What not to touch.

## What this layer is

The P.O.P.S. ORB is a cognitive wrapper that adds:
- A bounded legal semantic knowledge graph (SKG)
- A governance doctrine that wraps every LLM call
- A local + optional API LLM adapter, both governed
- A floating React UI component over the existing app
- A FastAPI router that mounts on your existing backend

It does NOT rebuild or alter the existing TPC core, Rust substrate, or
Proof of Presence database structure.

---

## Step 1 — Backend: wire the router (1 line)

In your existing `tpc_orb_desktop/backend/main.py`, add:

```python
# At the top:
import sys
sys.path.insert(0, '/path/to/pops_orb_layer')
from orb_bridge import orb_router

# After app = FastAPI():
app.include_router(orb_router, prefix="/orb")
```

The ORB API is then available at:
  GET  /orb/status
  POST /orb/chat
  POST /orb/skg/search
  GET  /orb/skg/node/{id}
  POST /orb/skg/link
  GET  /orb/lexicon

---

## Step 2 — Frontend: mount the floating ORB (1 component)

Copy `ui/POPSOrb.tsx` into:
  `tpc_orb_desktop/frontend/src/components/orb/POPSOrb.tsx`

In your existing `App.tsx`, add at the bottom of your root return:

```tsx
import { POPSOrb } from './components/orb/POPSOrb'

// Inside return (after all existing content):
<POPSOrb
  caseId={activeCaseId}        // pass from your existing case state
  jurisdiction={jurisdiction}  // optional — state abbreviation
/>
```

The component mounts as a fixed-position overlay. It does not affect
your existing layout.

---

## Step 3 — Install Python deps (layer only)

```bash
pip install httpx pyyaml fastapi pydantic
```

All already present if your TPC backend is running.

---

## Step 4 — Configure the LLM

Edit `orb_config.yaml`:

```yaml
# Use local Ollama (default):
llm_mode: "local"
ollama_host: "http://localhost:11434"
ollama_model: "qwen2.5:4b"

# OR use API LLM:
# llm_mode: "api"
# api_url: "https://api.openai.com/v1/chat/completions"
# api_key: "your-key"
# api_model: "gpt-4o-mini"
```

---

## Step 5 — Verify the doctrine hash

Run this once after setup:

```python
from governance.orb_doctrine import verify_doctrine, get_doctrine_hash
print(verify_doctrine())       # must be True
print(get_doctrine_hash())     # print and store — this is your lock
```

If `verify_doctrine()` returns False, the ORB will not serve chat requests.
The doctrine must match exactly. Do not alter `DOCTRINE_TEXT` in orb_doctrine.py.

---

## File layout (new files only)

```
pops_orb_layer/
├── governance/
│   └── orb_doctrine.py       # Locked governance wrapper
├── skg/
│   └── legal_skg.py          # Semantic knowledge graph
├── adapters/
│   └── llm_adapters.py       # Ollama + API adapters
├── ui/
│   └── POPSOrb.tsx           # Floating React component
├── orb_bridge.py             # FastAPI router (mount point)
├── orb_config.yaml           # Configuration
└── INTEGRATION.md            # This file
```

---

## What learns over time

The SKG (`pops_skg.json`) grows as you add verified case entries.
It learns from:
  - User-confirmed case facts (via /skg/link)
  - Approved sources you seed manually via `skg.add_verified_node()`

It does NOT learn from:
  - LLM outputs
  - Unverified web content
  - User assumptions

The governance doctrine is locked. It does not learn or change.

---

## Advice boundary

The ORB will never say: "You should file..."
It will say: "This may be relevant to discuss with an attorney.
Here are the facts and documents to organize."

This is enforced at three layers:
1. Input gate (governance.check_lane)
2. System prompt wrapper (governance.wrap_system_prompt)
3. Output filter (governance.filter_output)

All three are applied to every LLM call, regardless of mode.
