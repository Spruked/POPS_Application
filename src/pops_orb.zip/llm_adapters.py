"""
P.O.P.S. ORB — LLM Adapter Layer
Governs both local Ollama and optional API LLM.
Both adapters pass through the same governance wrapper.
The governance wrapper is not optional.
"""

import json
import httpx
import asyncio
from abc import ABC, abstractmethod
from typing import Optional, AsyncIterator
from dataclasses import dataclass

from governance.orb_doctrine import OrbGovernance


@dataclass
class OrbRequest:
    user_message: str
    case_context: dict
    skg_context: str
    stream: bool = False
    session_id: str = ""


@dataclass
class OrbResponse:
    content: str
    source: str
    governance_applied: bool = True
    filtered: bool = False
    fallback_used: bool = False


FALLBACK_RESPONSE = (
    "I do not have enough approved source material to answer that safely. "
    "I can help you organize the facts for attorney review."
)


class BaseOrbAdapter(ABC):
    """
    All LLM adapters for the P.O.P.S. ORB must inherit from this.
    Governance is applied at this layer — not in the UI, not in the SKG.
    """

    def __init__(self):
        self.governance = OrbGovernance()

    def build_prompt(self, request: OrbRequest) -> tuple[str, str]:
        """Returns (system_prompt, user_message) both governance-wrapped."""
        base_system = f"""
You are the P.O.P.S. ORB — a case-type-specific legal organizer for parents
navigating custody and parenting time matters. You help organize facts, explain
court language, connect evidence, and prepare packets for attorney review.

{request.skg_context}

{self.governance.build_context_block(request.case_context)}
"""
        system = self.governance.wrap_system_prompt(base_system)
        return system, request.user_message

    def post_filter(self, response: str) -> tuple[str, bool]:
        """Apply output filter. Returns (filtered_text, was_filtered)."""
        filtered = self.governance.filter_output(response)
        was_filtered = filtered != response
        return filtered, was_filtered

    def check_lane(self, message: str) -> tuple[bool, str]:
        return self.governance.check_lane(message)

    @abstractmethod
    async def call(self, request: OrbRequest) -> OrbResponse:
        pass

    @abstractmethod
    async def stream(self, request: OrbRequest) -> AsyncIterator[str]:
        pass


class OllamaOrbAdapter(BaseOrbAdapter):
    """
    Local Ollama adapter for the P.O.P.S. ORB.
    Connects to the existing Ollama instance (qwen or other).
    Governance wrapper applied at every call.
    """

    def __init__(
        self,
        host: str = "http://localhost:11434",
        model: str = "qwen2.5:4b",
        timeout: int = 60,
    ):
        super().__init__()
        self.host = host
        self.model = model
        self.timeout = timeout

    async def call(self, request: OrbRequest) -> OrbResponse:
        in_lane, reason = self.check_lane(request.user_message)
        if not in_lane:
            return OrbResponse(
                content=FALLBACK_RESPONSE,
                source="governance_block",
                fallback_used=True,
            )

        system, user_msg = self.build_prompt(request)

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(
                    f"{self.host}/api/chat",
                    json={
                        "model": self.model,
                        "stream": False,
                        "messages": [
                            {"role": "system", "content": system},
                            {"role": "user", "content": user_msg},
                        ],
                    },
                )
                data = resp.json()
                raw = data.get("message", {}).get("content", FALLBACK_RESPONSE)
        except Exception as e:
            return OrbResponse(
                content=f"Local LLM unavailable. {FALLBACK_RESPONSE}",
                source="ollama_error",
                fallback_used=True,
            )

        filtered, was_filtered = self.post_filter(raw)
        return OrbResponse(
            content=filtered,
            source=f"ollama:{self.model}",
            filtered=was_filtered,
        )

    async def stream(self, request: OrbRequest) -> AsyncIterator[str]:
        in_lane, reason = self.check_lane(request.user_message)
        if not in_lane:
            yield FALLBACK_RESPONSE
            return

        system, user_msg = self.build_prompt(request)

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                async with client.stream(
                    "POST",
                    f"{self.host}/api/chat",
                    json={
                        "model": self.model,
                        "stream": True,
                        "messages": [
                            {"role": "system", "content": system},
                            {"role": "user", "content": user_msg},
                        ],
                    },
                ) as resp:
                    buffer = ""
                    async for line in resp.aiter_lines():
                        if not line:
                            continue
                        try:
                            chunk = json.loads(line)
                            token = chunk.get("message", {}).get("content", "")
                            buffer += token
                            yield token
                        except json.JSONDecodeError:
                            continue
        except Exception:
            yield FALLBACK_RESPONSE


class APILLMOrbAdapter(BaseOrbAdapter):
    """
    Optional API LLM adapter (Claude, GPT, etc.).
    Same governance wrapper. Same advice boundary.
    Plug in when local LLM is unavailable or user opts in.
    """

    def __init__(
        self,
        api_url: str,
        api_key: str,
        model: str,
        timeout: int = 30,
    ):
        super().__init__()
        self.api_url = api_url
        self.api_key = api_key
        self.model = model
        self.timeout = timeout

    async def call(self, request: OrbRequest) -> OrbResponse:
        in_lane, reason = self.check_lane(request.user_message)
        if not in_lane:
            return OrbResponse(
                content=FALLBACK_RESPONSE,
                source="governance_block",
                fallback_used=True,
            )

        system, user_msg = self.build_prompt(request)

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user_msg},
            ],
            "max_tokens": 800,
        }

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(self.api_url, json=payload, headers=headers)
                data = resp.json()
                raw = data["choices"][0]["message"]["content"]
        except Exception:
            return OrbResponse(
                content=f"API LLM unavailable. {FALLBACK_RESPONSE}",
                source="api_error",
                fallback_used=True,
            )

        filtered, was_filtered = self.post_filter(raw)
        return OrbResponse(
            content=filtered,
            source=f"api:{self.model}",
            filtered=was_filtered,
        )

    async def stream(self, request: OrbRequest) -> AsyncIterator[str]:
        # Implement SSE streaming for API if needed
        response = await self.call(request)
        yield response.content


class OrbAdapterFactory:
    """Factory. Returns the right adapter based on config."""

    @staticmethod
    def build(config: dict) -> BaseOrbAdapter:
        mode = config.get("llm_mode", "local")

        if mode == "local":
            return OllamaOrbAdapter(
                host=config.get("ollama_host", "http://localhost:11434"),
                model=config.get("ollama_model", "qwen2.5:4b"),
            )
        elif mode == "api":
            return APILLMOrbAdapter(
                api_url=config.get("api_url", ""),
                api_key=config.get("api_key", ""),
                model=config.get("api_model", ""),
            )
        else:
            raise ValueError(f"Unknown llm_mode: {mode}")
