"""
P.O.P.S. ORB — FastAPI Bridge Router
Wire this into your existing main.py with a single app.include_router() call.
Does not touch your existing routes.

In your existing main.py, add:
    from pops_orb_layer.orb_bridge import orb_router
    app.include_router(orb_router, prefix="/orb")
"""

import json
import yaml
import hashlib
from pathlib import Path
from typing import Optional
from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from governance.orb_doctrine import OrbGovernance, verify_doctrine
from skg.legal_skg import LegalSKG
from adapters.llm_adapters import OrbAdapterFactory, OrbRequest

orb_router = APIRouter(tags=["P.O.P.S. ORB"])

# Load config
CONFIG_PATH = Path(__file__).parent / "orb_config.yaml"
if CONFIG_PATH.exists():
    with open(CONFIG_PATH) as f:
        ORB_CONFIG = yaml.safe_load(f)
else:
    ORB_CONFIG = {"llm_mode": "local", "ollama_host": "http://localhost:11434", "ollama_model": "qwen2.5:4b"}

skg = LegalSKG(storage_path=str(Path(__file__).parent / "pops_skg.json"))
governance = OrbGovernance()
adapter = OrbAdapterFactory.build(ORB_CONFIG)


class OrbChatRequest(BaseModel):
    message: str
    case_id: Optional[str] = None
    jurisdiction: Optional[str] = None
    stream: bool = False


class SKGSearchRequest(BaseModel):
    query: str


class CaseLinkRequest(BaseModel):
    entry_type: str
    entry_data: dict


class OrbStatusResponse(BaseModel):
    doctrine_verified: bool
    doctrine_hash: str
    skg_node_count: int
    llm_mode: str
    ready: bool


@orb_router.get("/status", response_model=OrbStatusResponse)
async def orb_status():
    """Health check. Confirms doctrine hash, SKG, and LLM adapter are ready."""
    from governance.orb_doctrine import get_doctrine_hash
    verified = verify_doctrine()
    return OrbStatusResponse(
        doctrine_verified=verified,
        doctrine_hash=get_doctrine_hash(),
        skg_node_count=len(skg.nodes),
        llm_mode=ORB_CONFIG.get("llm_mode", "local"),
        ready=verified,
    )


@orb_router.post("/chat")
async def orb_chat(req: OrbChatRequest):
    """
    Main ORB chat endpoint.
    Governance is applied before and after every LLM call.
    """
    if not verify_doctrine():
        raise HTTPException(status_code=500, detail="Governance doctrine verification failed.")

    in_lane, reason = governance.check_lane(req.message)
    if not in_lane:
        return {
            "response": (
                "I do not have enough approved source material to answer that safely. "
                "I can help you organize the facts for attorney review."
            ),
            "source": "governance_block",
            "fallback": True,
        }

    # Build case context block (in production, fetch from Proof of Presence DB)
    case_context = {
        "case_id": req.case_id or "unknown",
        "jurisdiction": req.jurisdiction or "not specified",
        "case_type": "custody/parenting",
        "order_count": 0,
        "evidence_count": 0,
        "violation_count": 0,
    }

    # Search SKG for relevant concepts
    skg_nodes = skg.search(req.message)[:5]
    skg_ids = [n.node_id for n in skg_nodes]
    skg_context = skg.export_for_prompt(skg_ids)

    orb_req = OrbRequest(
        user_message=req.message,
        case_context=case_context,
        skg_context=skg_context,
        stream=req.stream,
        session_id=req.case_id or "",
    )

    if req.stream:
        async def token_stream():
            async for token in adapter.stream(orb_req):
                yield f"data: {json.dumps({'token': token})}\n\n"
            yield "data: [DONE]\n\n"

        return StreamingResponse(token_stream(), media_type="text/event-stream")

    response = await adapter.call(orb_req)
    return {
        "response": response.content,
        "source": response.source,
        "fallback": response.fallback_used,
        "filtered": response.filtered,
        "skg_nodes_used": skg_ids,
    }


@orb_router.post("/skg/search")
async def skg_search(req: SKGSearchRequest):
    """Search the legal knowledge graph."""
    results = skg.search(req.query)[:8]
    return {
        "results": [
            {
                "id": n.node_id,
                "label": n.label,
                "category": n.category,
                "definition": n.definition,
                "court_language": n.court_language,
                "risk_flags": n.risk_flags,
                "related": n.related_ids,
            }
            for n in results
        ]
    }


@orb_router.get("/skg/node/{node_id}")
async def skg_node(node_id: str):
    """Get a specific SKG node and its related nodes."""
    node = skg.get_node(node_id)
    if not node:
        raise HTTPException(status_code=404, detail=f"SKG node '{node_id}' not found.")
    related = skg.find_related(node_id)
    return {
        "node": {
            "id": node.node_id,
            "label": node.label,
            "category": node.category,
            "definition": node.definition,
            "court_language": node.court_language,
            "risk_flags": node.risk_flags,
            "evidence_types": node.evidence_types,
        },
        "related": [
            {"id": r.node_id, "label": r.label, "category": r.category}
            for r in related
        ],
    }


@orb_router.post("/skg/link")
async def skg_link_entry(req: CaseLinkRequest):
    """
    Given a case entry, return SKG links and gaps.
    This is the semantic connector — links violations → orders → evidence → exhibits.
    """
    suggestions, gaps = skg.link_case_entry(req.entry_type, req.entry_data)
    suggestion_nodes = [skg.get_node(s) for s in suggestions if skg.get_node(s)]

    return {
        "entry_type": req.entry_type,
        "suggested_links": [
            {"id": n.node_id, "label": n.label, "court_language": n.court_language}
            for n in suggestion_nodes
        ],
        "gaps": gaps,
        "gap_count": len(gaps),
    }


@orb_router.get("/lexicon")
async def get_lexicon():
    """Return the full legal lexicon (all SKG nodes with court language)."""
    return {
        "terms": [
            {
                "id": n.node_id,
                "label": n.label,
                "category": n.category,
                "plain_english": n.definition,
                "court_language": n.court_language,
            }
            for n in skg.nodes.values()
        ],
        "total": len(skg.nodes),
    }
