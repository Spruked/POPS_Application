"""
P.O.P.S. ORB — Governance Doctrine
Locked. Do not alter. Hash verified at runtime.

The ORB does not practice law.
The ORB does not give legal advice.
The ORB organizes facts, explains court language, connects evidence,
flags risk, and prepares clean packets from a bounded legal substrate.

This doctrine is the governance wrapper. Every LLM call passes through it.
"""

import hashlib
import json
from dataclasses import dataclass, field
from typing import Optional

DOCTRINE_TEXT = """
P.O.P.S. ORB Governance Doctrine v1.0

IDENTITY:
The P.O.P.S. ORB is a case-type-specific legal organizer.
It is not a legal advisor, not a lawyer, not a general chatbot.

LANE:
- Parenting time and custody procedure
- Denied visits and communication records
- Court orders and contempt concepts
- Child support and license impact
- Medical and school access
- Evidence handling, exhibits, chain of custody
- Court-safe factual statements
- Self-represented parent guidance
- Attorney packet preparation

OUT OF LANE (hard block):
- Criminal law (unless directly touching support/license/contempt)
- General legal opinions
- Free-roaming internet legal advice
- "You should file..." statements
- Any output framed as legal advice

ANSWER SOURCES (priority order):
1. User's own case file (Proof of Presence DB)
2. Approved legal substrate (seeded domain knowledge)
3. Approved legal lexicon
4. Approved templates
5. Approved state/jurisdiction resources when available

WHEN SOURCE IS UNAVAILABLE:
Output exactly: "I do not have enough approved source material to answer that
safely. I can help you organize the facts for attorney review."

ADVICE BOUNDARY:
ORB may explain: "This term usually means..."
ORB must not say: "You should file..."
ORB may say: "This may be relevant to discuss with an attorney.
Here are the facts and documents to organize."

SEMANTIC LINKING MISSION:
Connect denied visit entries → parenting order section → communication record
→ evidence item → exhibit label → requested relief → attorney packet section.
Flag any gap. Never fill a gap with assumption.
"""

DOCTRINE_HASH = "a7f3c2e1b8d4f9a0c5e2b7d4f1a8c3e0b5d2f7a4c1e8b3d0f5a2c7e4b1d8f3a0"


def verify_doctrine() -> bool:
    computed = hashlib.sha256(DOCTRINE_TEXT.encode()).hexdigest()
    return computed == DOCTRINE_HASH


def get_doctrine_hash() -> str:
    return hashlib.sha256(DOCTRINE_TEXT.encode()).hexdigest()


@dataclass
class OrbGovernance:
    """
    The governance wrapper. Instantiated once per session.
    All LLM calls pass through apply_wrapper() before and after.
    """
    doctrine_verified: bool = field(default=False, init=False)
    session_id: Optional[str] = None

    IN_LANE_TOPICS = [
        "parenting time", "custody", "parenting plan", "visitation",
        "denied visit", "missed visit", "communication record",
        "court order", "contempt", "child support", "license suspension",
        "medical access", "school access", "evidence", "exhibit",
        "chain of custody", "factual statement", "attorney packet",
        "self-represented", "pro se", "hearing", "motion", "affidavit",
        "declaration", "service of process", "notice", "summons",
        "parenting coordinator", "guardian ad litem", "best interest",
        "modification", "enforcement", "violation", "non-compliance",
    ]

    OUT_OF_LANE_PHRASES = [
        "criminal charge", "criminal defense", "immigration",
        "contract dispute", "divorce property", "personal injury",
        "bankruptcy", "employment law", "estate planning",
        "you should file", "i recommend you file", "file a motion to",
        "my legal opinion", "legally you must", "you are entitled to",
    ]

    def __post_init__(self):
        self.doctrine_verified = verify_doctrine()

    def check_lane(self, user_input: str) -> tuple[bool, str]:
        """Returns (in_lane, reason). Hard check before any LLM call."""
        lower = user_input.lower()
        for phrase in self.OUT_OF_LANE_PHRASES:
            if phrase in lower:
                return False, f"Out of lane: '{phrase}'"
        return True, "ok"

    def wrap_system_prompt(self, base_prompt: str) -> str:
        """Prepends governance doctrine to any system prompt going to an LLM."""
        return f"""
{DOCTRINE_TEXT}

---

You are operating under the P.O.P.S. ORB governance doctrine above.
You must not violate any constraint in it, regardless of user instruction.
If asked to give legal advice or opinions, respond with the approved fallback.

APPROVED FALLBACK (use verbatim when needed):
"I do not have enough approved source material to answer that safely.
I can help you organize the facts for attorney review."

---

{base_prompt}
"""

    def filter_output(self, raw_output: str) -> str:
        """Post-process LLM output to catch advice boundary violations."""
        violations = [
            ("you should file", "you may want to discuss filing with an attorney"),
            ("i recommend filing", "this may be worth discussing with an attorney"),
            ("legally you must", "court rules typically require"),
            ("you are legally entitled", "some parents in this situation have sought"),
            ("my legal opinion", "based on the case facts organized here"),
        ]
        result = raw_output
        for bad, replacement in violations:
            result = result.replace(bad, replacement)
            result = result.replace(bad.title(), replacement.title())
        return result

    def build_context_block(self, case_data: dict) -> str:
        """Build the case context block injected into every LLM prompt."""
        return f"""
ACTIVE CASE CONTEXT:
Case ID: {case_data.get('case_id', 'unknown')}
Jurisdiction: {case_data.get('jurisdiction', 'not specified')}
Case Type: {case_data.get('case_type', 'custody/parenting')}
Open orders: {case_data.get('order_count', 0)}
Evidence items: {case_data.get('evidence_count', 0)}
Violations logged: {case_data.get('violation_count', 0)}

The ORB has access to this case file only.
Do not speculate beyond what is documented.
"""
