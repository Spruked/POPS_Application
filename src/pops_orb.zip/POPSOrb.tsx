/**
 * P.O.P.S. ORB — Floating Legal Assistant Component
 * Drop this into the existing Proof of Presence React app.
 * Mounts as a floating overlay. Does not touch existing layout.
 *
 * Usage in App.tsx:
 *   import { POPSOrb } from './components/POPSOrb'
 *   // Add inside your root return:
 *   <POPSOrb caseId={activeCaseId} jurisdiction={caseJurisdiction} />
 */

import { useState, useRef, useEffect, useCallback } from 'react'

const ORB_API = 'http://localhost:8000/orb'

interface Message {
  id: string
  role: 'user' | 'orb'
  content: string
  fallback?: boolean
  skg_nodes?: string[]
  timestamp: number
}

interface SKGNode {
  id: string
  label: string
  category: string
  plain_english: string
  court_language: string
}

interface POPSOrbProps {
  caseId?: string
  jurisdiction?: string
}

type OrbPanel = 'chat' | 'lexicon' | 'link'

const DOCTRINE_NOTICE =
  'The P.O.P.S. ORB organizes facts and explains court language. ' +
  'It does not practice law or give legal advice.'

function OrbAvatar({ size = 40 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" style={{ display: 'block', flexShrink: 0 }}>
      <circle cx="20" cy="20" r="18" fill="#0d4f3c" />
      <circle cx="20" cy="20" r="13" fill="none" stroke="#2dd4a0" strokeWidth="1.5" strokeDasharray="4 2" />
      <circle cx="20" cy="20" r="6" fill="#2dd4a0" opacity="0.9" />
      <circle cx="20" cy="20" r="2.5" fill="#0d4f3c" />
    </svg>
  )
}

function CategoryBadge({ category }: { category: string }) {
  const colors: Record<string, { bg: string; text: string }> = {
    court_concept: { bg: '#e6f1fb', text: '#0c447c' },
    evidence_type: { bg: '#eaf3de', text: '#27500a' },
    procedure: { bg: '#faeeda', text: '#633806' },
    risk: { bg: '#fcebeb', text: '#791f1f' },
    document: { bg: '#e1f5ee', text: '#085041' },
    person_role: { bg: '#eeedfe', text: '#3c3489' },
    relief_type: { bg: '#fbeaf0', text: '#72243e' },
  }
  const style = colors[category] || { bg: '#f1efe8', text: '#444441' }
  return (
    <span style={{
      fontSize: 11, padding: '2px 8px', borderRadius: 4,
      background: style.bg, color: style.text,
      fontWeight: 500, whiteSpace: 'nowrap',
    }}>
      {category.replace('_', ' ')}
    </span>
  )
}

export function POPSOrb({ caseId, jurisdiction }: POPSOrbProps) {
  const [open, setOpen] = useState(false)
  const [panel, setPanel] = useState<OrbPanel>('chat')
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [lexicon, setLexicon] = useState<SKGNode[]>([])
  const [lexiconSearch, setLexiconSearch] = useState('')
  const [linkEntry, setLinkEntry] = useState<{ type: string; gaps: string[]; links: any[] } | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)

  useEffect(() => {
    if (open && panel === 'lexicon' && lexicon.length === 0) {
      fetchLexicon()
    }
  }, [open, panel])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const fetchLexicon = async () => {
    try {
      const res = await fetch(`${ORB_API}/lexicon`)
      const data = await res.json()
      setLexicon(data.terms || [])
    } catch {
      // silently fail — ORB may be starting
    }
  }

  const sendMessage = useCallback(async () => {
    if (!input.trim() || loading) return
    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input.trim(),
      timestamp: Date.now(),
    }
    setMessages(prev => [...prev, userMsg])
    setInput('')
    setLoading(true)

    try {
      const res = await fetch(`${ORB_API}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userMsg.content,
          case_id: caseId,
          jurisdiction,
          stream: false,
        }),
      })
      const data = await res.json()
      const orbMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'orb',
        content: data.response,
        fallback: data.fallback,
        skg_nodes: data.skg_nodes_used,
        timestamp: Date.now(),
      }
      setMessages(prev => [...prev, orbMsg])
    } catch {
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        role: 'orb',
        content: 'ORB is offline. Ensure the backend is running on port 8000.',
        timestamp: Date.now(),
      }])
    } finally {
      setLoading(false)
      setTimeout(() => inputRef.current?.focus(), 50)
    }
  }, [input, loading, caseId, jurisdiction])

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  const filteredLexicon = lexiconSearch
    ? lexicon.filter(n =>
        n.label.toLowerCase().includes(lexiconSearch.toLowerCase()) ||
        n.plain_english.toLowerCase().includes(lexiconSearch.toLowerCase())
      )
    : lexicon

  const orbBtnStyle: React.CSSProperties = {
    position: 'fixed', bottom: 28, right: 28, zIndex: 9999,
    width: 56, height: 56, borderRadius: '50%',
    background: '#0d4f3c', border: '2px solid #2dd4a0',
    cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
    boxShadow: '0 4px 24px rgba(0,0,0,0.35)',
    transition: 'transform 0.15s',
  }

  const panelStyle: React.CSSProperties = {
    position: 'fixed', bottom: 96, right: 28, zIndex: 9998,
    width: 400, height: 560, borderRadius: 14,
    background: '#0a2e22', border: '1px solid #1a5c44',
    display: 'flex', flexDirection: 'column', overflow: 'hidden',
    boxShadow: '0 8px 40px rgba(0,0,0,0.5)',
    fontFamily: 'system-ui, sans-serif',
  }

  const tabStyle = (active: boolean): React.CSSProperties => ({
    padding: '8px 14px', fontSize: 13, fontWeight: active ? 500 : 400,
    color: active ? '#2dd4a0' : '#7aa899', cursor: 'pointer',
    borderBottom: active ? '2px solid #2dd4a0' : '2px solid transparent',
    background: 'none', border: 'none', borderRadius: 0,
    borderBottomColor: active ? '#2dd4a0' : 'transparent',
    transition: 'color 0.1s',
  })

  if (!open) {
    return (
      <button
        style={orbBtnStyle}
        onClick={() => setOpen(true)}
        title="Open P.O.P.S. ORB"
      >
        <OrbAvatar size={34} />
      </button>
    )
  }

  return (
    <>
      {/* Toggle button */}
      <button
        style={{ ...orbBtnStyle, background: '#1a5c44' }}
        onClick={() => setOpen(false)}
        title="Close ORB"
      >
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
          <path d="M5 5l10 10M15 5L5 15" stroke="#2dd4a0" strokeWidth="2" strokeLinecap="round" />
        </svg>
      </button>

      {/* Panel */}
      <div style={panelStyle}>
        {/* Header */}
        <div style={{
          padding: '14px 16px 0', borderBottom: '1px solid #1a5c44',
          display: 'flex', flexDirection: 'column', gap: 0,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
            <OrbAvatar size={28} />
            <div>
              <div style={{ fontSize: 14, fontWeight: 600, color: '#e0f5ee' }}>P.O.P.S. ORB</div>
              <div style={{ fontSize: 11, color: '#7aa899' }}>Case organizer · not legal advice</div>
            </div>
            {caseId && (
              <span style={{
                marginLeft: 'auto', fontSize: 11, color: '#2dd4a0',
                background: '#0d4f3c', padding: '2px 8px', borderRadius: 4,
              }}>
                {caseId}
              </span>
            )}
          </div>
          <div style={{ display: 'flex', gap: 0 }}>
            {(['chat', 'lexicon', 'link'] as OrbPanel[]).map(p => (
              <button key={p} style={tabStyle(panel === p)} onClick={() => setPanel(p)}>
                {p === 'chat' ? 'Ask ORB' : p === 'lexicon' ? 'Legal Lexicon' : 'Link Entry'}
              </button>
            ))}
          </div>
        </div>

        {/* CHAT PANEL */}
        {panel === 'chat' && (
          <>
            <div style={{
              flex: 1, overflowY: 'auto', padding: '12px 14px', display: 'flex', flexDirection: 'column', gap: 10,
            }}>
              {messages.length === 0 && (
                <div style={{
                  fontSize: 12, color: '#5c8c7a', lineHeight: 1.6, padding: '8px 0',
                  borderLeft: '2px solid #1a5c44', paddingLeft: 10,
                }}>
                  {DOCTRINE_NOTICE}
                </div>
              )}
              {messages.map(msg => (
                <div key={msg.id} style={{
                  display: 'flex', gap: 8,
                  flexDirection: msg.role === 'user' ? 'row-reverse' : 'row',
                }}>
                  {msg.role === 'orb' && <OrbAvatar size={24} />}
                  <div style={{
                    maxWidth: '85%', fontSize: 13, lineHeight: 1.6,
                    color: msg.role === 'user' ? '#e0f5ee' : '#c5e8db',
                    background: msg.role === 'user' ? '#0d4f3c' : '#0f3829',
                    padding: '8px 12px', borderRadius: 10,
                    border: msg.fallback ? '1px solid #5c8c7a' : 'none',
                  }}>
                    {msg.content}
                    {msg.fallback && (
                      <div style={{ fontSize: 11, color: '#5c8c7a', marginTop: 4 }}>
                        ↳ governance fallback applied
                      </div>
                    )}
                    {msg.skg_nodes && msg.skg_nodes.length > 0 && (
                      <div style={{ fontSize: 11, color: '#2dd4a0', marginTop: 4 }}>
                        SKG: {msg.skg_nodes.join(', ')}
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {loading && (
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <OrbAvatar size={24} />
                  <div style={{ fontSize: 13, color: '#5c8c7a' }}>ORB is organizing…</div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
            <div style={{ padding: '10px 12px', borderTop: '1px solid #1a5c44', display: 'flex', gap: 8 }}>
              <textarea
                ref={inputRef}
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={handleKey}
                placeholder="Ask about your case, a term, or an exhibit…"
                rows={2}
                style={{
                  flex: 1, resize: 'none', fontSize: 13, lineHeight: 1.5,
                  background: '#0d4f3c', color: '#e0f5ee', border: '1px solid #2dd4a0',
                  borderRadius: 8, padding: '8px 10px',
                  fontFamily: 'inherit', outline: 'none',
                }}
              />
              <button
                onClick={sendMessage}
                disabled={loading || !input.trim()}
                style={{
                  width: 40, borderRadius: 8, background: '#2dd4a0', border: 'none',
                  color: '#0a2e22', cursor: loading ? 'not-allowed' : 'pointer',
                  fontWeight: 700, fontSize: 18,
                  opacity: loading || !input.trim() ? 0.4 : 1,
                }}
              >
                ↑
              </button>
            </div>
          </>
        )}

        {/* LEXICON PANEL */}
        {panel === 'lexicon' && (
          <div style={{ flex: 1, overflowY: 'auto', padding: '12px 14px', display: 'flex', flexDirection: 'column', gap: 10 }}>
            <input
              value={lexiconSearch}
              onChange={e => setLexiconSearch(e.target.value)}
              placeholder="Search legal terms…"
              style={{
                fontSize: 13, background: '#0d4f3c', color: '#e0f5ee',
                border: '1px solid #2dd4a0', borderRadius: 8, padding: '8px 10px',
                fontFamily: 'inherit', outline: 'none',
              }}
            />
            {filteredLexicon.map(term => (
              <div key={term.id} style={{
                background: '#0f3829', borderRadius: 8, padding: '10px 12px',
                border: '1px solid #1a5c44',
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                  <span style={{ fontSize: 13, fontWeight: 600, color: '#e0f5ee' }}>{term.label}</span>
                  <CategoryBadge category={term.category} />
                </div>
                <div style={{ fontSize: 12, color: '#c5e8db', lineHeight: 1.5, marginBottom: 4 }}>
                  {term.plain_english}
                </div>
                <div style={{ fontSize: 11, color: '#2dd4a0', fontStyle: 'italic' }}>
                  Court language: "{term.court_language}"
                </div>
              </div>
            ))}
            {filteredLexicon.length === 0 && (
              <div style={{ fontSize: 13, color: '#5c8c7a' }}>No terms match that search.</div>
            )}
          </div>
        )}

        {/* LINK ENTRY PANEL */}
        {panel === 'link' && (
          <div style={{ flex: 1, overflowY: 'auto', padding: '12px 14px', display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div style={{ fontSize: 13, color: '#7aa899', lineHeight: 1.6 }}>
              Link a case entry to the legal knowledge graph. The ORB will identify gaps and suggested connections.
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              {['violation', 'evidence', 'event'].map(type => (
                <button
                  key={type}
                  onClick={async () => {
                    try {
                      const res = await fetch(`${ORB_API}/skg/link`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                          entry_type: type,
                          entry_data: { type },
                        }),
                      })
                      const data = await res.json()
                      setLinkEntry({ type, gaps: data.gaps, links: data.suggested_links })
                    } catch {
                      setLinkEntry({ type, gaps: ['ORB offline. Cannot fetch links.'], links: [] })
                    }
                  }}
                  style={{
                    padding: '6px 14px', borderRadius: 8, fontSize: 13,
                    background: '#0d4f3c', color: '#2dd4a0', border: '1px solid #2dd4a0',
                    cursor: 'pointer', fontFamily: 'inherit',
                  }}
                >
                  {type}
                </button>
              ))}
            </div>

            {linkEntry && (
              <>
                <div style={{ fontSize: 12, fontWeight: 600, color: '#e0f5ee' }}>
                  Suggested links for: {linkEntry.type}
                </div>
                {linkEntry.links.map((link: any) => (
                  <div key={link.id} style={{
                    background: '#0f3829', borderRadius: 8, padding: '8px 12px',
                    border: '1px solid #1a5c44', fontSize: 12,
                  }}>
                    <div style={{ fontWeight: 600, color: '#2dd4a0', marginBottom: 2 }}>{link.label}</div>
                    <div style={{ color: '#7aa899', fontStyle: 'italic' }}>"{link.court_language}"</div>
                  </div>
                ))}
                {linkEntry.gaps.length > 0 && (
                  <div style={{
                    background: '#2a1010', borderRadius: 8, padding: '10px 12px',
                    border: '1px solid #6b3030',
                  }}>
                    <div style={{ fontSize: 12, fontWeight: 600, color: '#f09595', marginBottom: 6 }}>
                      Gaps detected:
                    </div>
                    {linkEntry.gaps.map((gap, i) => (
                      <div key={i} style={{ fontSize: 12, color: '#f09595', lineHeight: 1.6 }}>
                        ⚠ {gap}
                      </div>
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </div>
    </>
  )
}
