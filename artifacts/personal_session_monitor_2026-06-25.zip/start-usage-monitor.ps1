$ErrorActionPreference = "Stop"

$source = if ($args.Count -gt 0) { $args[0] } else { "manual" }
wsl.exe bash -lc "/home/bryan/projects/personal-session-monitor/start.sh --source '$source'"
