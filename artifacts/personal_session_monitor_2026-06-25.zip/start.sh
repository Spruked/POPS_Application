#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT="${RECORDS_USAGE_MONITOR_PORT:-18440}"
PID_FILE="$APP_DIR/.usage-monitor.pid"
LOG_FILE="$APP_DIR/.usage-monitor.log"
SOURCE="manual"
OPEN_BROWSER="1"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --source)
      SOURCE="${2:-manual}"
      shift 2
      ;;
    --no-browser)
      OPEN_BROWSER="0"
      shift
      ;;
    *)
      shift
      ;;
  esac
done

if [[ -f "$PID_FILE" ]] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
  :
else
  cd "$APP_DIR"
  nohup python3 -m http.server "$PORT" --bind 127.0.0.1 >"$LOG_FILE" 2>&1 &
  echo "$!" > "$PID_FILE"
fi

URL="http://127.0.0.1:${PORT}/?source=${SOURCE}"
echo "$URL"

if [[ "$OPEN_BROWSER" == "1" ]]; then
  if command -v powershell.exe >/dev/null 2>&1; then
    powershell.exe -NoProfile -Command "Start-Process '$URL'" >/dev/null 2>&1 || true
  elif command -v xdg-open >/dev/null 2>&1; then
    xdg-open "$URL" >/dev/null 2>&1 || true
  fi
fi
