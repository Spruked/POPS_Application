# Personal Session Monitor

Standalone WSL-hosted timer for personal VS Code, Codex, GPT, Copilot, and Gemini usage records.

## Run From WSL

```bash
cd ~/projects/personal-session-monitor
./start.sh --source manual
```

Default URL:

```text
http://127.0.0.1:18440/
```

## Features

- 5-hour session timer.
- Daily reset time, default `04:40`.
- Manual percent override, useful when the provider usage meter is approximate.
- VS Code opened event.
- Codex opened event.
- Checkpoint event.
- Active visible time and hidden/background time.
- Event log.
- JSON export.
- CSV export.
- Summary copy.
- Local browser persistence.

## VS Code Auto-Start

The user-level VS Code task calls:

```powershell
wsl.exe bash -lc "/home/bryan/projects/personal-session-monitor/start.sh --source vscode-folder-open --no-browser"
```

This starts the WSL monitor server when any VS Code workspace opens. VS Code may ask once to allow automatic tasks.
